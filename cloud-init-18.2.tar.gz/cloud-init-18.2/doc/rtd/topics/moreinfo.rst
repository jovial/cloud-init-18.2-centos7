****************
More information
****************

Useful external references
==========================

- `The beauty of cloudinit`_
- `Introduction to cloud-init`_ (video)

.. _Introduction to cloud-init: http://www.youtube.com/watch?v=-zL3BdbKyGY
.. _The beauty of cloudinit: http://brandon.fuller.name/archives/2011/05/02/06.40.57/
.. vi: textwidth=78
